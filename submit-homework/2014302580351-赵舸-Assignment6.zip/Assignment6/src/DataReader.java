import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DataReader {

	public static Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
			System.out.println("ע�������ɹ�");
			return conn;
		} catch (ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
			System.out.println("ע������ʧ��");
			return null;
		}
	
	}

	public static Customer LogIn(String username,String password)
	{
		Customer customer=new Customer();
		boolean isExist=false;
		Connection conn=getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=conn.prepareStatement("SELECT * FROM 2014302580351_user;");
			rs=ps.executeQuery();
			while(rs.next())
			{
				if(username.equals(rs.getString(2))&&password.equals(rs.getString(3)))
				{
					isExist=true;
					customer.setUsername(rs.getString(2));
					customer.setSex(rs.getString(4));
					customer.setPhone(rs.getString(5));
					customer.setEmail(rs.getString(6));
				}
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
		}finally
		{
			try
			{
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
			
			
		}
		if(isExist==true)
			return customer;
		else
		{
			JOptionPane.showMessageDialog( null,"��ż���ף������Ǵ���",
					  "Error", JOptionPane.PLAIN_MESSAGE );
			return null;
			
		}
	}
	
	
	public static boolean Register(String username,String password,String sex,String phone,String email)
	{   int i=0;
		if(username.equals("")||password.equals("")||sex.equals("")||phone.equals("")||email.equals(""))
		{
			JOptionPane.showMessageDialog( null,"��������������",
					  "Error", JOptionPane.PLAIN_MESSAGE );
			return false;
		}
		String registerSql="insert into 2014302580351_user(id,username,password,sex,phone,email) values('"+i+"','"+username+"','"+password+"','"+sex+"','"+phone+"','"+email+"');";
;		Connection conn=getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		i++;

		try
		{
			ps=conn.prepareStatement("SELECT * FROM 2014302580351_user;");
			rs=ps.executeQuery();
			while(rs.next())
			{	
				if(username.equals(rs.getString(1)))
				{
					JOptionPane.showMessageDialog( null,"��������Ѿ����Ǽ���",
							  "Error", JOptionPane.PLAIN_MESSAGE );
					return false;
				}
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
		}finally
		{
			try
			{
				rs.close();
				ps.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}			
		}
		
		
		try
		{
			ps=conn.prepareStatement(registerSql);
			ps.executeUpdate(registerSql);	
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}			
		}
		JOptionPane.showMessageDialog( null,"ŷ�ˣ��Ѿ��ǼǺ���",
				  "Congratulation", JOptionPane.PLAIN_MESSAGE );
		return true;
		
	}
	

	public ArrayList<Pet> read()
	{
		ArrayList<Pet> petList=new ArrayList<Pet>();
		Connection conn=getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=conn.prepareStatement("SELECT * FROM pet;");
			rs=ps.executeQuery();
			while(rs.next())
			{
				Pet temp=new Pet();
				temp.setId(Integer.valueOf(rs.getInt(1)));
				temp.setName(rs.getString(2));
				temp.setEat(rs.getString(3));
				temp.setDrink(rs.getString(4));
				temp.setLive(rs.getString(5));
				temp.setHobby(rs.getString(6));
				System.out.println(rs.getString(2));
				petList.add(temp);				
			}
			System.out.println("�е�");
			return petList;
			
		} catch (SQLException e)
		{
			e.printStackTrace();
			System.out.println("�յ�");
			return null;
		}finally
		{
			try
			{
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
			
			
		}
	}
}
