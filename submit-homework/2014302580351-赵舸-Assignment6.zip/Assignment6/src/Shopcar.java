import java.util.ArrayList;

public class Shopcar {

	private ArrayList<Good> good;
	public Shopcar()
	{
		good=new ArrayList<Good>();
	}

	public ArrayList<Good> getGood()
	{
		return good;
	}

	public void setGood(ArrayList<Good> good)
	{
		this.good = good;
	}

}
