
public class Good {
	private Pet pet;
	private int number;
	private double price;
	public Good()
	{
		number=0;
	}
	public Pet getPet()
	{
		return pet;
	}
	public void setPet(Pet pet)
	{
		this.pet = pet;
	}
	public int getNumber()
	{
		return number;
	}
	public void setNumber(int number)
	{
		this.number = number;
	}
	public double getPrice()
	{
		return price;
	}
	public void setPrice(double price)
	{
		this.price = price;
	}
}
