import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class GUI {
	private JFrame Petframe;
	private ShowPanel showPanel;

	public GUI() {
		initialize();
	}
	
	 private void initialize() {
	 Petframe = new JFrame();
	 Petframe.setSize(600, 700);
	 Toolkit kit = Toolkit.getDefaultToolkit();
	 Dimension screenSize = kit.getScreenSize();
	 Petframe.setLocation(screenSize.width / 2 - 300, screenSize.height / 2 -
	 350);
	 Petframe.setTitle("�����̵�");
	 Petframe.setVisible(true);
	 Petframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	 LogInPanel loginPanel = new LogInPanel();
	 showPanel = new ShowPanel();
	
	 Petframe.add(loginPanel);
	 Petframe.add(showPanel);
	 showPanel.setCustomer(loginPanel.getCustomer());
	
	 loginPanel.setVisible(true);
	 showPanel.setVisible(false);
	
	 }
}

class LogInPanel extends JPanel {
	private Customer customer;

	public Customer getCustomer() {
		return this.customer;
	}

	public LogInPanel() {
		setSize(600, 700);
		this.setLayout(null);
		JTextField username = new JTextField();
		JPasswordField userpassword = new JPasswordField();
		JLabel userLabel = new JLabel("���˵�����:");
		JLabel passwordLabel = new JLabel("���˵Ķ�����ζ:");
		JButton ensureButton = new JButton("�������֮�ң�");
		JButton createButton = new JButton("ȫ�µĿɰ����ˣ��Ǽ�������Ϣ�ɣ�");
		customer = new Customer();
		ensureButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user = username.getText().trim();
				String password = new String(userpassword.getPassword());
				customer = DataReader.LogIn(user, password);
				if (customer != null) {
					LogInPanel.this.setVisible(false);
					LogInPanel.this.getParent().getComponent(1).setVisible(true);
				}
			}
		});
		createButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean isAdd = false;
				CreatePanel createPanel = new CreatePanel();
				if (isAdd == false) {
					LogInPanel.this.getParent().add(createPanel);
					isAdd = true;
				}
				LogInPanel.this.setVisible(false);
				createPanel.setVisible(true);
			}

		});
	
	
		add(userLabel);
		add(passwordLabel);
		add(username);
		add(userpassword);	
		add(ensureButton);
		add(createButton);
		
		userLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		userLabel.setBounds(100,100,200,40);
		passwordLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		passwordLabel.setBounds(80,140,240,40);
		username.setBounds(300,100,200,40);
		userpassword.setBounds(300,140,200,40);
		ensureButton.setBounds(130,300,300,40);
		createButton.setBounds(130,360,300,40);
	
	
	
	
	}
}

class CreatePanel extends JPanel {
	public CreatePanel() {
		setSize(600, 700);
		this.setLayout(null);

		JLabel registerLabel = new JLabel("��¼������Ϣ");
		JLabel usernameLabel = new JLabel("���������˵�������");
		JLabel passwordLabel = new JLabel("���������˵���ζ��");
		JLabel sexLabel = new JLabel("�������˻���Ů���ˣ�");
		JLabel phoneLabel = new JLabel("���˵�����绰��");
		JLabel emailLabel = new JLabel("���˵��������䣺");

		JTextField usernameText = new JTextField();
		JTextField passwordText = new JTextField();
		JTextField sexText = new JTextField();
		JTextField phoneText = new JTextField();
		JTextField emailText = new JTextField();

		JButton backButton = new JButton("���ص�½ҳ��");
		JButton registerButton = new JButton("��Ҫ�Ǽǣ�");

		backButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				CreatePanel.this.setVisible(false);
				CreatePanel.this.getParent().getComponent(0).setVisible(true);

			}

		});

		registerButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				DataReader.Register(usernameText.getText().trim(), passwordText.getText().trim(),
						sexText.getText().trim(), phoneText.getText().trim(), emailText.getText().trim());
			}

		});

		add(registerLabel);
		add(usernameLabel);
		add(passwordLabel);
		add(sexLabel);
		add(phoneLabel);
		add(emailLabel);
		add(usernameText);
		add(passwordText);
		add(sexText);
		add(phoneText);
		add(emailText);
		add(backButton);
		add(registerButton);

		registerLabel.setFont(new Font("����", Font.BOLD, 25));
		usernameLabel.setFont(new Font("����", Font.BOLD, 25));
		passwordLabel.setFont(new Font("����", Font.BOLD, 25));
		sexLabel.setFont(new Font("����", Font.BOLD, 25));
		phoneLabel.setFont(new Font("����", Font.BOLD, 25));
		emailLabel.setFont(new Font("����", Font.BOLD, 25));

		registerLabel.setBounds(250, 20, 100, 30);
		usernameLabel.setBounds(100, 50, 100, 30);
		usernameText.setBounds(200, 50, 200, 30);
		passwordLabel.setBounds(80, 100, 120, 30);
		passwordText.setBounds(200, 100, 200, 30);
		sexLabel.setBounds(140, 200, 100, 30);
		sexText.setBounds(200, 200, 200, 30);
		phoneLabel.setBounds(110, 250, 100, 30);
		phoneText.setBounds(200, 250, 200, 30);
		emailLabel.setBounds(120, 300, 100, 30);
		emailText.setBounds(200, 300, 200, 30);

		backButton.setBounds(150, 350, 100, 50);
		registerButton.setBounds(300, 350, 100, 50);

	}

}

class ShowPanel extends JPanel {
	private DataReader dataReader;
	private ArrayList<Pet> petList;
	private ArrayList<Good> goodList;
	private JButton[] petButton;
	private ImageIcon[] petimage;
	private JButton shopcarButton;
	private Customer customer;
	public String petName;
	private int money = 0;
    
	public int getMoney(){
    	return money;
    }
	public void setMoney(int money){
		this.money=money;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
		this.customer.shopcar.setGood(goodList);
	}

	public ShowPanel() {
		setSize(600, 700);
		this.setLayout(null);

		dataReader = new DataReader();
		petList = dataReader.read();
		goodList = new ArrayList<Good>();
		petButton = new JButton[12];
		petimage = new ImageIcon[12];
		customer = new Customer();

		for (int i = 0; i < 12; i++) {
			Good good = new Good();
			good.setPrice(100);
			good.setPet(petList.get(i));
			goodList.add(good);
		}
		for (int i = 0; i < 12; i++) {
			petName = petList.get(i).getName();
			String imgURL = petName+".jpg";
			petimage[i] = new ImageIcon(imgURL);
			petButton[i] = new JButton(petimage[i]);
			petButton[i].addActionListener(new DetailAction(i));
			add(petButton[i]);
			petButton[i].setBounds((i % 3) * 200 + 50, (i / 3) * 130 + 15, 100, 100);
		}

		shopcarButton = new JButton("�鿴���ﳵ");
		shopcarButton.addActionListener(new ShopcarAction());

		add(shopcarButton);
		shopcarButton.setBounds(200, 600, 100, 40);

	}

	private class ShopcarAction extends AbstractAction {
		private boolean isAdd;
		private ShopcarPanel shopcarPanel;

		public ShopcarAction() {
			shopcarPanel = new ShopcarPanel(goodList);
			isAdd = false;
		}

		public void actionPerformed(ActionEvent arg0) {
			ShowPanel.this.setVisible(false);
			if (isAdd == false) {
				ShowPanel.this.getParent().add(shopcarPanel);
				isAdd = true;
			}
			shopcarPanel.Refresh();
			shopcarPanel.setVisible(true);

		}

	}

	private class DetailAction extends AbstractAction {
		private DetailPanel detailPanel;
		private boolean isAdd;

		public DetailAction(int i) {
			isAdd = false;
			detailPanel = new DetailPanel(goodList.get(i));
		}

		public void actionPerformed(ActionEvent e) {
			ShowPanel.this.setVisible(false);
			if (isAdd == false) {
				ShowPanel.this.getParent().add(detailPanel);
				isAdd = true;
			}
			detailPanel.setVisible(true);

		}

	}

	class DetailPanel extends JPanel {
		private Good good;
		private Pet pet;
		private JLabel pictureLabel;
		private JLabel idLabel;
		private JLabel nameLabel;
		private JLabel eatLabel;
		private JLabel drinkLabel;
		private JLabel liveLabel;
		private JLabel hobbyLabel;
		private JLabel priceLabel;

		private JButton backButton;
		private JTextField numberText;
		private JButton purchaseButton;
		
		public DetailPanel(Good good) {
			setSize(600, 700);
			this.setLayout(null);

			this.good = good;
			this.pet = this.good.getPet();
			String imgURL =this.pet.getName()+".jpg";
			pictureLabel = new JLabel(new ImageIcon(imgURL));
			idLabel = new JLabel("id:" + String.valueOf(this.pet.getId()));
			nameLabel = new JLabel("name:" + this.pet.getName());
			eatLabel = new JLabel("eat:" + this.pet.getEat());
			drinkLabel = new JLabel("drink:" + this.pet.getDrink());
			liveLabel = new JLabel("live:" + this.pet.getLive());
			hobbyLabel = new JLabel("hobby:" + this.pet.getHobby());
			priceLabel = new JLabel("price:" + this.good.getPrice());
			backButton = new JButton("�����̵�㳡");
			purchaseButton = new JButton("����");

			add(pictureLabel);
			add(idLabel);
			add(nameLabel);
			add(eatLabel);
			add(drinkLabel);
			add(liveLabel);
			add(hobbyLabel);
			add(priceLabel);
			add(backButton);
			add(purchaseButton);

			backButton.addActionListener(new BackAction());
			purchaseButton.addActionListener(new PurchaseAction());

			idLabel.setFont(new Font("����", 0, 25));
			nameLabel.setFont(new Font("����", 0, 25));
			eatLabel.setFont(new Font("����", 0, 25));
			drinkLabel.setFont(new Font("����", 0, 25));
			liveLabel.setFont(new Font("����", 0, 25));
			hobbyLabel.setFont(new Font("����", 0, 25));
			priceLabel.setFont(new Font("����", 0, 25));

			pictureLabel.setBounds(100, 50, 100, 100);
			idLabel.setBounds(100, 160, 500, 30);
			nameLabel.setBounds(100, 200, 500, 30);
			eatLabel.setBounds(100, 240, 500, 30);
			drinkLabel.setBounds(100, 280, 500, 30);
			liveLabel.setBounds(100, 320, 500, 30);
			hobbyLabel.setBounds(100, 360, 500, 30);
			priceLabel.setBounds(100, 400, 500, 30);
			purchaseButton.setBounds(350, 500, 100, 40);
			backButton.setBounds(200, 600, 100, 40);

		}

		private class BackAction extends AbstractAction {
			public void actionPerformed(ActionEvent e) {
				DetailPanel.this.setVisible(false);
				DetailPanel.this.getParent().getComponent(1).setVisible(true);
			}
		}

		private class PurchaseAction extends AbstractAction {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�Ѽ��빺�ﳵ", "Error", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
}

class ShopcarPanel extends JPanel {
	private Shopcar shopcar;
	private ArrayList<JLabel> nameLabel;
	private JButton purchaseButton;
	private JButton backButton;

	public void Refresh() {
		int goodNumber = 0;
		for (int i = 0; i < shopcar.getGood().size(); i++) {
			if (shopcar.getGood().get(i).getNumber() > 0) {
				nameLabel.get(i).setBounds(50, i * 50, 200, 50);
				nameLabel.get(i).setVisible(true);
				goodNumber++;
			} else {
				nameLabel.get(i).setVisible(false);
			}
		}

	}

	public ShopcarPanel(ArrayList<Good> goodList) {
		setSize(600, 700);
		this.setLayout(null);
		shopcar = new Shopcar();
		shopcar.setGood(goodList);

		purchaseButton = new JButton("�����ؼ�");
		backButton = new JButton("��ȥ����");


		add(backButton);
		add(purchaseButton);
		backButton.addActionListener(new BackAction());
		purchaseButton.addActionListener(new PurchaseAction());

		backButton.setBounds(100, 600, 100, 50);
		purchaseButton.setBounds(300, 600, 100, 50);

	}

	private class BackAction extends AbstractAction {
		public void actionPerformed(ActionEvent e) {
			ShopcarPanel.this.setVisible(false);
			ShopcarPanel.this.getParent().getComponent(1).setVisible(true);

		}

	}

	private class PurchaseAction extends AbstractAction {
		public void actionPerformed(ActionEvent e) {
			int all = 0;
			for (int i = 0; i < 12; i++) {
				all += shopcar.getGood().get(i).getPrice();
			}
			JOptionPane.showMessageDialog(null, "��ϲ�㹺��ɹ�", "Error", JOptionPane.PLAIN_MESSAGE);
			for (int i = 0; i < 12; i++) {
				shopcar.getGood().get(i).setNumber(0);
				Refresh();
			}
		}

	}

}
